ps -e | wc -l
