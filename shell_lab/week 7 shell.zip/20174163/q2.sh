y=$1
cd $y
ls | wc -w

