x=$1
y=$2

cd $x

if [ -f "$y" ]
then
	cat $y
else
	echo "not exist "
fi

