x=$1
y=$2

cd $x

if [ -f "$y" ]
then
	ls -al $y
	ls -l $y
else
	echo "not exist "
fi

