y=$1
for file in $y/*
do 
	if grep -q "vaishnav" $(basename "$file")
	then 
	echo "$file"
	fi
done

