
for i in {100..105}
do
	mkdir $i
	cp $1 $i
	cd $i
done

	

