y=$1

for ip in $(cat $y)
do 
	ping -c 1 $ip
	if [ $? -eq 0 ]
	then 
	echo "program connected"
	else
	echo "fail"
	fi
done
