from array  import * 
arr1=array('i',[1,3,5,7,9])
print("original array :"+str(arr1))
print("inserting new value 4 before 3:")
arr1.insert(1,4)
print("New array: "+str(arr1))

