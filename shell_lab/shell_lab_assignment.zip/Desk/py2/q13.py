dic1={1:30,2:29,3:28}
dic2={4:27,5:26,6:25}
dic3={7:24,8:23,9:22}
res={}
res.update(dic1)
res.update(dic2)
res.update(dic3)
print(res)
