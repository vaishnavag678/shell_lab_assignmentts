
print("enter a password")
x=raw_input()
schar=False
uchar=False
digit=False
echar=False
length=len(x)
if length<6 or length>16:
 print("Inavalid")
else:
 for i in range(0,length):
  if x[i]>='a' and x[i]<='z':
   schar=True
  elif x[i]>='A' and x[i]<='Z':
   uchar=True
  elif x[i]>='0' and x[i]<='9':
   digit=True
  elif x[i]=='$' or x[i]=='#' or x[i]=='@':
   echar=True
 if schar and uchar and digit and echar:
  print("valid")
 else:
  print("Invalid")

