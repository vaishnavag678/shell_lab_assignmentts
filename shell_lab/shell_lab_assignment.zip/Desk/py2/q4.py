print("enter a string ")
str1=raw_input()
upper=0
lower=0
for i in range(0,len(str1)):
 if str1[i]>='A' and str1[i]<='Z':
  upper+=1
 elif str1[i]>='a' and str1[i]<='z':
  lower+=1
print("number of uppercase character :"+str(upper))
print("number of lower case character :"+str(lower))
