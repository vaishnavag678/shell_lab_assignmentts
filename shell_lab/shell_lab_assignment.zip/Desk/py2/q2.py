print("enter the number of rows and colomns")
n=input();
m=input();
list1=[]
for i in range(0,n):
 tmp=[]
 for j in range(0,m):
   tmp.append(i*j)
 list1.append(tmp)
print(list1)
