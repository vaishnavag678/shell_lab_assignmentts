
print("entet the number of iteams of list")
n=input()
list1=[]
sta=set()
for i in range(0,n):
 print("enter list element")
 x=input()
 list1.append(x)
for i in range(0,n):
 sta.add(list1[i])
print(sta)
