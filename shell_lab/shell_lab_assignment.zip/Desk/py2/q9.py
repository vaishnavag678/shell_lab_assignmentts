
import datetime
print("enter year month and day")
yy=input()
mm=input()
dd=input()
dt=datetime.date(yy,mm,dd)
print("The next date is "+str(dt+datetime.timedelta(days=1)))
