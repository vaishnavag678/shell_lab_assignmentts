from array import *
arr1=array('i',[])
print("enter the size of array")
n=input()
for i in range(0,n):
 print("enter array element")
 x=input()
 arr1.insert(i,x)
print("original array :"+str(arr1))
list1=arr1.tolist()
print("convert the said array in a list with same iteams :")
print(list1)
