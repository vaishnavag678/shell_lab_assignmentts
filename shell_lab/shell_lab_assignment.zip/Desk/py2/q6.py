def fun():
 x=1
 y=2
 str1="satyam"
 print("count local variable")
print(fun.__code__.co_nlocals)
