from array import *
print("enter array size")
n=input()
print("enter array element")
arr1=array('i',[])
for i in range(0,n):
 print("enter array element ")
 x=input()
 arr1.insert(i,x)
print("original array "+str(arr1))
print("current memory address and the length in elements of the buffer: "+str(arr1.buffer_info()))
print("the size of the memory buffer in bytes :"+str(arr1.buffer_info()[1]*arr1.itemsize))
