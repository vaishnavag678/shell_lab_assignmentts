
def fun():
 list1=[]
 while True :
  print("enter a string")
  x=raw_input()
  length=len(x)
  if length==0:
   break
  else:
   list1.append(x.lower())
 print(list1)
print(fun())
