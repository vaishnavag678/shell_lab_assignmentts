for i in range(1,51):
 if i%3==0 and i%5==0:
  print("FizzBiZZ")
 elif i%3==0:
  print("Fizz")
 else:
  print("BiZZ")

 
