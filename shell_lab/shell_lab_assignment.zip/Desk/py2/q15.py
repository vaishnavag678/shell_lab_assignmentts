import operator
x = {"Math": 81, "Physics": 83, "Chemistry": 87}
sorted_x = sorted(x, key=x.get,reverse=True)
print(sorted_x)
