import psutil
class CPU:
	def cpu_Times(self):
		a=psutil.cpu_times()
		print ("User: ",a[0])
		print("System: ",a[2])
		print("Idle: ",a[3])
		
	def cpu_Percent(self):
		for x in range(3):
			psutil.cpu_percent(interval=1)
			
	def cpu_Stats(self):
		a=psutil.cpu_stats()
		print ("Context Switch",a[0])
		print ("Interrupt",a[1])
		print ("Soft Interrupt",a[2])
		print ("System Calls",a[3])
		
	def cpu_Frequency(self):
		a=psutil.cpu_freq()
		print("Current: ",a[0])
		print("Min: ",a[1])
		print("Max: ",a[2])
		
class Memory():
	def virtual(self):
		print (psutil.virtual_memory(),"\n")
	def swap_mem(self):
		print (psutil.swap_memory(),"\n")
	def disk(self):
		print (psutil.disk_partitions(),"\n")
	def disk_use(self):
		print (psutil.disk_usage('/'),"\n")
	def disk_io(self):
		print (psutil.disk_io_counters(perdisk=False),"\n")
		
class Network():
	def net_io(self):
		print (psutil.net_io_counters(pernic=True),"\n")
	def net_con(self):
		print (psutil.net_connections())
	def net_if(self):
		print(psutil.net_if_addrs())
	def net_stats(self):
		print (psutil.net_if_stats())
		
class Process():
	def pid(self):	
		print (psutil.pids())
	def snap(self):
		a=int(input("Enter process ID"))
		try:
			print (psutil.Process(a))
		except:
			print("Not Valid Id")
		
p1=CPU()


p2=Memory()


p3=Network()



p4=Process()

a=int(input("Enter the Option"))
if a==1:
	p1.cpu_Times()
	p1.cpu_Percent()
	p1.cpu_Stats()
	p1.cpu_Frequency()
elif a==2:
	p2.virtual()
	p2.swap_mem()
	p2.disk()
	p2.disk_use()
	p2.disk_io()
elif a==3:
	p3.net_io()
	p3.net_con()
	p3.net_if()
elif a==4:
	p4.pid()
	p4.snap()
else:
	print ("Not a Valid Option")


