a=file("test.txt",'r')
b=file("tst.txt",'r')
list1=[i for i in a]
list2=[i for i in b]
for i in range(min(len(list1),len(list2))):
 print(list1[i].split("\n")[0]+" "+list2[i])

