
def fndlong(a):
 list1=[]
 x=""
 maxi=-1
 list1=a.split(" ")
 for i in range(0,len(list1)):
  length=len(list1[i])
  if length>maxi:
   maxi=length
   x=list1[i]
 print("longest word"+x)
string=raw_input()
print(fndlong(string))
