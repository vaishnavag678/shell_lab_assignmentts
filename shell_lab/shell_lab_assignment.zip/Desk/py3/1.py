class q1:
 top=-1
 
 def check(self,a):
  flag=0
  list1=[]
  for i in range(0,len(a)):
   if a[i]=='{' or a[i]=='(' or a[i]=='[':
    list1.append(a[i])
   else:
    ch=list1.pop()
    if a[i]=='}' and ch!='{':
     flag=1
     break
    elif a[i]==')' and ch!='(':
     flag=1
     break
    elif a[i]==']' and ch!='[':
     flag=1
     break
    else:
     continue
  if flag==1:
   print("unbalanced")
  else:
   print("balanced")
print("enter a string of brackets")
string=raw_input()
p1=q1()
p1.check(string)
  

