class q4:
 x=""
 def get_String(self,a):
  self.x=str(a)
 def print_String(self):
  print(self.x.upper())
p1=q4()
print("enter a string")
string=raw_input()
p1.get_String(string)
p1.print_String()
  
