import re
text = "MNNIT Computer Club is a gem in itself."
for m in re.finditer(r"\w+IT", text):
    print('%d-%d: %s' % (m.start(), m.end(), m.group(0)))
