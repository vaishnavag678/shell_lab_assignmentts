awk -F, '{print $3,$4}' trace > op2.txt
