awk -F, '{print $5}' trace
