awk -F, '{

	if($5=="\"HTTP\"")
	print $3

}' trace
