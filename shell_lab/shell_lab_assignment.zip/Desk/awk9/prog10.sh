awk -F "," '{
if(($3=="\"172.31.132.7\"") && ($4=="\"172.31.132.5\"") && ($7=="\"GET / HTTP/1.1 \"")){
    if(i==0){
        flag=1
        i++
    }
}
if(($3=="\"172.31.132.5\"") && ($4=="\"172.31.132.7\"") && ($7=="\"HTTP/1.1 200 OK  (text/html)\"")){
    if(j==0){
        flag=0
        j++
    }
}
if((flag==1) && ($5=="\"TCP\"")){
    tcp[0]++
    tcp[2]=$6
    var=substr(tcp[2],2,length(tcp[2])-2)
    tcp[1]+=var
}
}END{
print "No. of TCP :-\n" tcp[0]
print "Length of TCP:-\n" tcp[1]
}' trace
