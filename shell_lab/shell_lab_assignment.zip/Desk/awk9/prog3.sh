awk -F, '{

	if($5=="\"ARP\"") ar[$3]++
	}
	
	END {
		for(key in ar)
		print key
	}' trace
	
	

