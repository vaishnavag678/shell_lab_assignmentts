ls -al
