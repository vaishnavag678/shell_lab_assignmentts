
echo enter file name
read file
C=`cat $file |wc -c`
l=`grep -c "." $file`
echo number of lines in $file is $l
