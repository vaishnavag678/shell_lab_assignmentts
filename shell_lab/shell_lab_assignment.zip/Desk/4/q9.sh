
echo enter file1 name
read file1
echo enter file2 name
read file2
echo enter deti file
read file3
cat $file1 $file2

cat $file1 $file2 >$file3
echo output file 
cat combi.txt
