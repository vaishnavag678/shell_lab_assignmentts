
echo enter two numbers
read a
read b
echo enter your choice
read ch

if [ $ch = "1" ];then
result=`expr $a + $b`
echo "Result: $result"

fi
if [ $ch = "2" ];
then 
result=`expr $a - $b`
echo "Result: $result"
fi
if [$ch = 3 ];
then 
result="expr $a * $b"
echo "Result: $result"

fi
if [ $ch = 4 ];
then 
result=`expr $a / $b`
echo "Result: $result"

fi
