ls $1
