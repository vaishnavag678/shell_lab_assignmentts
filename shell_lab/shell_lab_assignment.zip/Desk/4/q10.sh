
for i in {1..5}
do 
mkdir file$i
done
