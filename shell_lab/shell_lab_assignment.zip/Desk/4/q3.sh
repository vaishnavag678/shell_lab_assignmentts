
c1='cd /home/user/Documents'
c2='cd /home/user/Downloads'
echo PATH=$PATH:$c1
echo after c1 executed 
echo PATH=$PATH:$c1
echo ater c2 executed $c2
echo PATH=$PATH:$c2
