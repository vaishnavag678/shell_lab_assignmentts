number1 = input("First number: ") 
number2 = input("\nSecond number: ")
print("Dividing {0} by {1}" .format(number1, number2))
number3 = number1 % number2
if number3 == 0 :
	print("Divisible")
else :
	print("Not divisible")
print("GOODBYE!")
