number1 = input("Enter Age: ") 
dif = 60 - number1
if dif < 0 :
	print("You should already be RETIRED")
elif dif == 0 :
	print("Congrats You will be retiring this year")
else :
	print("You still have {0} years to go till your retirement" .format(dif))
print("GOODBYE!")
