number1 = input("First number: ") 
number2 = input("\nSecond number: ") 
sum = float(number1) + float(number2) 
print("The sum of {0} and {1} is {2}" .format(number1, number2, sum)) 
