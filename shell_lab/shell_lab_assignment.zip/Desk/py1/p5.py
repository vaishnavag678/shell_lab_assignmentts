user_input = raw_input ("enter : ")
try:
    val = int(user_input)
    print("Yes input string is an Integer.")
except ValueError:
       print("That's a string")
