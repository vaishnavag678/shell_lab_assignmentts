lspids()
{
/bin/ps -ef | grep “$1”| grep -v grep ;
}
lspids $1
