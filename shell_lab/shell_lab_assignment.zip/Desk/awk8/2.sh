awk '{
if($2 == "A")
res+=$3*9;
if($2 == "B")
res+=$3*8;
if($2 == "C")
res+=$3*7;
}END{ print "grade "res/24}' GPA.txt
