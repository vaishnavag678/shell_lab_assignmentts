awk -F ":" '{
if($1 == "B")
{
tot=$2
}
if($1 == "D")
{
tot=tot+$4;
print $2" "$4
}
if($1 == "C")
{
tot=tot-$4;
print $2" "tot
}
if($1 == "W")
{
tot=tot-$4
print $2" "tot
}
}' account.txt
