awk '{s_price+=$2}END{print s_price}{s_quantity+=$3}END{print s_quantity}' fruit_prices.txt
