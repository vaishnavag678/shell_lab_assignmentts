awk '{ print $1" " $3+$4+$5}' marks.txt
