awk 'NR==1, NR==3 {print $1" " $2" " $5}' marks.txt
