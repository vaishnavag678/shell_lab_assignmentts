awk 'NR==6 {print $1" " $2" " $5}' marks.txt
