awk 'NR==1,NR==7 {res=$3+$4+5; if(max < res){max=res;na=$1;} }
END{print "topper " na "  Total " max}' marks.txt

