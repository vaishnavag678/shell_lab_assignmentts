echo "Enter String to be searched"
read string
for var in "$@"
do
	grep -r $string $var -q
	if(($?==0))
	then
		echo "String found in $var"
	fi
done
