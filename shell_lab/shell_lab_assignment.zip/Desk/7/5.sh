mkdir -p {1..10}/{1..5}
for i in {1..10}
do
	for j in {1..5}
	do
		cat dummy.txt >> test.txt
		mv test.txt $i/$j
	done
done
