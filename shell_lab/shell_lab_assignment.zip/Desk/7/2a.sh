#!/bin/sh

if [ -d "$PWD" ]; then
    echo "Number of files is $(find "$PWD" -type f | wc -l)"
    echo "Number of directories is $(find "$PWD" -type d | wc -l)"
else
    echo "[ERROR]  Please provide a directory."
    exit 1
fi
