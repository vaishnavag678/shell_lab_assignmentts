cd
cd $1
while true
do
	a=$(ls | wc -l)
	if ((a!=0))
	then
		break
	fi
done
echo "File Created"
