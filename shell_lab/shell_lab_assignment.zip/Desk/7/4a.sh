#!/bin/bash

NUM1=0
printf "\n Please enter a file name "
read num3
while [ $NUM1 -ne 1 ]
do
printf "\n Please enter the path to check "
read path2check

if find $path2check -name $num3 -print -quit |
   grep -q '^'; then
  echo "the file exists!"
  echo $(ls -l /$path2check/$num3)
  cat $path2check/$num3
  NUM1=$((NUM1+1))
  echo $NUM1
else
  echo "the file does not exist!"
fi

done
