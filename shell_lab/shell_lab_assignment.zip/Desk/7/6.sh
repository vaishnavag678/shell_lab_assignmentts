while read col1
do
	ping $col1 -c 2 >> ip.txt
	if(($?==0))
	then
		echo "$col1 is reachable"
	else
		echo "$col1 is not reachable"
	fi
done <ip.csv
