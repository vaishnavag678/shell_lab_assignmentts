ps --no-headers | wc -l
