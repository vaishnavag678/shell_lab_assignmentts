for i in {1..10};
do 
	echo $i \* $1 = `echo $i*$1 | bc -l`
done
