echo -n "Enter first number :"
read n1
echo -n "Enter second number :"
read n2

if [ $n1 > $n2 ]; then
	min=$n2
	max=$n1
else
	min=$n1
	max=$n2
fi

for i in `seq $min -1 1`;
do
	t1=$(( min % i))
	t2=$(( max % i ))
	if [ $t1 == 0 -a $t2 == 0 ]; then
		echo $i
		break
	fi
done
