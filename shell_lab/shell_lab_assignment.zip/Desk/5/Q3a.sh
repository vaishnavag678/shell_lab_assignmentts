echo -n "Enter a number:"
read n

for j in `seq 2 $n`;
do
	flag=0

	lim=`echo "sqrt($j)" | bc -l`


	for i in $(seq 2 $lim);
	do
		temp=$(( $j % i ))
	
		if [ $temp -eq 0 ]; then
			flag=1
		fi
	done

	if (( flag == "0" )); then
		echo $j
	fi
done
