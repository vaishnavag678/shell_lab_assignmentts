var1=1
var2=1
sum=1

for i in `seq 3 $1`;
do
	var2=$sum	
	sum=$(( $sum + var1 ))
	var1=$var2
done

echo $sum
	
	
