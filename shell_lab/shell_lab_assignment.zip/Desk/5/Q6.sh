op=$1
n1=$2
n2=$3
if [ $op == "-a" ]; then
add=$(( $n1 + $n2 ))
echo $add
elif [ $op == "-s" ]; then
sub=$(( $n1 - $n2 ))
echo $sub
elif [ $op == "-m" ]; then
mult=$(( $n1 * $n2 ))
echo $mult
elif [ $op == "-c" ]; then
div=$(( $n1 / $n2 ))
echo $div
else
rem=$(( $n1 % $n2 ))
echo $rem
fi
