if [ $1 > $2 ]; then
	min=$2
	max=$1
else
	min=$1
	max=$2
fi

for i in `seq $min -1 1`;
do
	t1=$(( min % i))
	t2=$(( max % i ))
	if [ $t1 == 0 -a $t2 == 0 ]; then
		echo $i
		break
	fi
done
