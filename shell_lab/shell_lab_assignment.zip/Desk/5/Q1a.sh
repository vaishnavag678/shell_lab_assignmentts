echo "Enter the number:"
read n

for i in {1..10};
do 
	echo $i \* $n = `echo $i*$n | bc -l`
done
