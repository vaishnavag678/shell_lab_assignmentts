echo -n "Enter a number:"
read n
flag=0

lim=`echo "sqrt($n)" | bc -l`


for i in $(seq 2 $lim);
do
	temp=$(( $n % i ))
	
	 if [ $temp -eq 0 ]; then
		flag=1
	fi
done

if (( flag == "1" )); then
	echo "Not a prime"
else
	echo "Prime"
fi
