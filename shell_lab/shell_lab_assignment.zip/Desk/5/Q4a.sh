echo -n "Enter the position number: "
read n

var1=1
var2=1
sum=1

for i in `seq 3 $n`;
do
	var2=$sum	
	sum=$(( $sum + var1 ))
	var1=$var2
done

echo $sum
	
	
