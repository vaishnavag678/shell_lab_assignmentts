flag=0

lim=`echo "sqrt($1)" | bc -l`


for i in $(seq 2 $lim);
do
	temp=$(( $1 % i ))
	
	 if [ $temp -eq 0 ]; then
		flag=1
	fi
done

if (( flag == "1" )); then
	echo "Not a prime"
else
	echo "Prime"
fi
