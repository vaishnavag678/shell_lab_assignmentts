echo Number of arguments:$#

for i in $@; 
do 	
	echo $i
done

sum=0

for i in $@; 
do 	
	sum=`expr $sum + $i`
done

echo Sum = $sum
