sleep 50 & 

echo PID of shell executing the script : $$

echo PID of last background process : $!

echo "${@: -1}"

echo $?
