who | grep user
echo $?
