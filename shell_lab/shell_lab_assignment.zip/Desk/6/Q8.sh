array=($@)
echo ${array[@]: 7}

shift 7
echo $@
