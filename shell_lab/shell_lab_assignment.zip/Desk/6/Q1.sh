echo Number of arguments:$#

echo $1 $2 $3

sum=$(($1+$2+$3))

echo Sum = $sum
