for i in $@;
do
	chmod +x $i
done
