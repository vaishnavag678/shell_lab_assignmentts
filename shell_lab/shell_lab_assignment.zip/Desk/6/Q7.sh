string=$1

echo ${string:0}

echo ${string:2:1}

echo ${string:2:-2}

echo ${string: -7:-2}
