ls -l
cat /home/user/sample.txt
echo $?
