echo Number of arguments:$#

for i in $@; 
do 	
	echo $i
done

avg=0

for i in $@; 
do 	
	avg=`expr $avg + $i`
done

avg=`echo $avg/$# | bc -l`

echo Avg = $avg
