dic = {"Jan":"31 days" , "Feb":"28/29 days" , "March":"31 days" , "April":"30 days" , "May":"31 days" , "June":"30 days" , "July":"31 days" , "August":"31 days" , "Sept":"30 days" , "Oct":"31 days" , "Nov":"30 days" , "Dec":"31 days"}
m = raw_input("Enter the month: ")
print "No. of days in",m,"is",dic[m]
