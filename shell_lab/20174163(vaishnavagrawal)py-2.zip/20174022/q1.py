for i in range(1 , 51):
   if(i%3==0 and i%5==0):
     print("FIZZBUZZ")
   elif i%3==0:
     print("FIZZ")
   else:
     print("BUZZ")
