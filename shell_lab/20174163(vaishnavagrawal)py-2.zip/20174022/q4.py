def fun(s):
        ctu = 0
        ctl = 0
        for i in s:
                ascii = ord(i)
                if ascii>=65 and ascii <=90:
                        ctu+=1
                elif ascii>=97 and ascii <= 122:
                        ctl+=1
        return ctu , ctl
        
s = raw_input("Enter The String: ")
ct = fun(s)
print "Upper case char :",ct[0]
print "Lower Case char :",ct[1]
