from collections import Counter
a = Counter({'Math':81, 'Physics':83, 'Chemistry':87})
print(a.most_common())
