lines = []
while True :
        l = raw_input()
        if l :
                lines.append(l.lower())
        else :
                break 
for i in lines :
        print i
