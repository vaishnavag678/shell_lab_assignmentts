def unique(l1):
        l = []
        for i in l1:
                if i not in l:
                        l.append(i)
        print l
l1 = []
n = input("Enter the no. elements in list ")
for i in range(n):
  x = int(input())
  l1.append(x)
  
print("List with unique elements :")
unique(l1)
