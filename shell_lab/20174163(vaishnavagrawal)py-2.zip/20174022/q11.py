from array import *
def array_list(array_num): 
	num_list = array_num.tolist() 
	print(num_list)
	 
arr = array('i', [1 , 2 , 3 , 4 , 5]) 
array_list(arr)
