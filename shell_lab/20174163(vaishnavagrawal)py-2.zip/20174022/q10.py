n = input("Enter Number of Elements :")
l = []
for i in range(n):
        l.append(raw_input("Enter Element "))

se = raw_input("Elemented to be inserted before 2nd element :");
l.append(None)
for i in range(n-1 , 0 , -1):
        l[i+1] = l[i]
l[1] = se
print l
        
