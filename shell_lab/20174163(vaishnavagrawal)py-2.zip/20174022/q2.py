m = int(input("Enter row: "))
n = int(input("Enter Column: "))

for i in range(m):
  for j in range(n):
    print i*j ,
  print
 
