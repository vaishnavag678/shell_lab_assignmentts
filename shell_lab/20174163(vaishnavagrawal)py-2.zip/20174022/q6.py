def fun():
        val = 5
        val2 = 6
        str = "Saurabh"

print fun.__code__.co_nlocals
