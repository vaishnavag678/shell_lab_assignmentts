special_str = "$#@"
passwords = raw_input("Enter password to check: ")



lower = 0
upper = 0
digits = 0
special = 0

for char in passwords:

	if char.islower():
		lower += 1
	elif char.isupper():
		upper += 1
	elif char.isdigit():
		digits += 1
	elif special_str.find(char) != -1:
		special += 1

if lower >= 1 and upper >= 1 and digits >= 1 and special >= 1 and len(passwords) in range(8,17):
	print "Valid"
else :
        print "Invalid"
