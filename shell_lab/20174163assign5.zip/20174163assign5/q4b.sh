n=$1
a=0
b=1


for (( i=0; i<n; i++))
do
	echo $a
	next=$((a+b))
	a=$b
	b=$next
done 
