num=$1
i=1
p=10
while test $i -le $p
do
echo `expr $num \* $i`

i=`expr $i + 1` 
done
 
