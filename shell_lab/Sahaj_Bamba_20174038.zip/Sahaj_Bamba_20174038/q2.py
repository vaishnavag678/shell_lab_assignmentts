class distinct_sub_sets():
	"""docstring for ClassName"""
	def __init__(self, arg):
		self.arg = arg
	
	def pr(self):
		#print(self.arg),
		for i in range(0,pow(2,len(self.arg))):
			#print(i)
			#j=i
			a=[]
			for k in range(0,len(self.arg)):
				#print(k),
				if (i & (1<<k)) != 0:
					pass
				else :
					a.append(self.arg[k])
		#print("]"),
			print(a)
			
x=distinct_sub_sets(input("Enter a list "))
x.pr()