import math
def fac(n):
	if n==1:
		return 1
		pass
	return n*fac(n-1)
	pass

print(math.factorial(1000))