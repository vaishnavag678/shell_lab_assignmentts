
def func(input):
	result=''
	for c in input:
		if c.isupper():
			result+=' '+c
		else:
			result+=c
	print result
if __name__ == "__main__": 
    input = raw_input("Enter String in Camel Case:")
    func(input) 
