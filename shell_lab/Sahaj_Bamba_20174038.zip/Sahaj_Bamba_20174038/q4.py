class my(object):
	"""docstring for my"""
	def __init__(self, arg):
		super(my, self).__init__()
		self.arg = arg
		
	def get_String(self):
		self.arg = raw_input("Give me a string ")

	def print_String(self):
		print(self.arg)

x=my("hi")
x.get_String()
x.print_String()