n = int(raw_input("Enter value of n:"))
sum=0.0
for i in xrange(1,n+1):
	sum+=1.0/float(i)
print 'Sum = ',sum
