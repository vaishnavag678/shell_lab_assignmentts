def removed(str,arg):
	x=str.split()
	#print(x)
	y=len(str)
	i=0
	while True:
		if len(x)<=i :
			break
		if len(x[i])<arg:
			#print(i)
			x.remove(x[i])
			i-=1
			y-=1
			if i>=y :
				break
		i+=1
	z=" ".join(x)
	print(z)
removed("jksdfh kf afuh afdvb sfb m bm kdfhs laf ibndv",5)