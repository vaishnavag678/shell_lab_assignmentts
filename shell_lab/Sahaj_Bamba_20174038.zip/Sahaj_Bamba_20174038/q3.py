class three_sum_zero():
	"""docstring for three_sum_zero"""
	def __init__(self, arg):
		self.arg = arg
	
	def pr(self):
		n=len(self.arg)
		for i in xrange(0,n):
			for j in xrange(i+1,n):
				for k in xrange(j+1,n):
					if (self.arg[i]+self.arg[j]+self.arg[k]) == 0 :
						a=[]
						a.append(self.arg[i])
						a.append(self.arg[j])
						a.append(self.arg[k])
						print a
						pass
					pass
				pass
			pass
x=three_sum_zero(input("Enter a list "))
x.pr()