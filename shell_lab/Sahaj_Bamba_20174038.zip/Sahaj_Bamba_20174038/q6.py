x=raw_input()
y=x.split()
#print(y)
x=0
for i in y :
	x=max(x,len(i))
	pass
for i in y:
	if len(i)==x:
		print(i)
		pass
	pass