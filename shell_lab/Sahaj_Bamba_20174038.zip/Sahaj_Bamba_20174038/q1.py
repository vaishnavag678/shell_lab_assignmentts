class parentheses():
	def __init__(self, arg):
		#super(parentheses, self).__init__()
		self.arg = arg
	
	def validate(self):
		a=[]
		f=0
		print(self.arg)
		for i in self.arg :
			if i=='(' or i=='{' or i=='[':
				a.append(i)
			else :
				if len(a)==0:
					#print(i)
					f=1
					break
				x=a.pop()
				if ( i==')' and x=='(' ) or ( i==']' and x=='[' ) or ( i=='}' and x=='{' ):
					pass
				else :
					f=1
					break
		if f==0:
			print("Right")
		else :
			print("Wrong")

par = parentheses(raw_input("Enter a string of parentheses"))
par.validate()