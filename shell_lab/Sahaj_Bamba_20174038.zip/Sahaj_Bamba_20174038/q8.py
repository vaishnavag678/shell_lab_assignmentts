def fun(arg):
	for i in xrange(0,arg):
		print(pow(11,i))
x=input("Enter number of rows in the triangle ")
fun(x)