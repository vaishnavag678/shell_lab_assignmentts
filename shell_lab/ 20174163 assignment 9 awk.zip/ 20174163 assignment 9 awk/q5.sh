awk -F , '
 
{ if ( $3 ~ /172.31.132.7/ ){
if ( $4 ~ /172.31.132.5/ ){
if ( $5 ~/TCP/ ){
cnt++;
}
}
}
}
END { print cnt } ' trace > q4.txt
