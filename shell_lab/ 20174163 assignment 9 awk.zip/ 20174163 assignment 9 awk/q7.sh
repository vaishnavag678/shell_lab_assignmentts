#!/bin/bash
awk -F "\"*,\"*" 'BEGIN{t=-1}{if($3=="172.31.132.7"&&$4=="172.31.132.5"&&t==-1&&$7=="GET / HTTP/1.1 \""){t=$2; e=$1}}END{ print "Time" t; print "Event" e}' trace
