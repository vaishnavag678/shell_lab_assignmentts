#!/bin/bash
awk -F "\"*,\"*" 'BEGIN{t=-1}{if($4=="172.31.132.7"&&$3=="172.31.132.5"&&t==-1&&$7=="HTTP/1.1 200 OK  (text/html)\""){t=$2; e=$1}}END{ print "Time" t; print "Event" e}' trace
