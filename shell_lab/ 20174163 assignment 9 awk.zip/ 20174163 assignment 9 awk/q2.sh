awk -F , '{a[$3]++}; END { for (d in a) print d } ' trace >> source.txt

awk -F , ' {b[$4]++}; END { for (d in b) print d } ' trace >> desti.txt


