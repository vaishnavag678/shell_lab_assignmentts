#!/bin/bash
awk -F , '{ if($5 ~ /ARP/) print $3 }' trace > ARPS.txt

