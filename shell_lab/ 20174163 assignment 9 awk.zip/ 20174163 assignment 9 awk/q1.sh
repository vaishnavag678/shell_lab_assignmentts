awk -F , '{a[$5]++}; END { for (b in a) print b } ' trace
