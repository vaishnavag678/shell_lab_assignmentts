n=int(raw_input("enter the number of row you want to need "))
print 1

for i in range(1,n):
	print 11**i
	

