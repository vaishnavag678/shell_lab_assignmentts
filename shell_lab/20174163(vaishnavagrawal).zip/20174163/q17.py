n=int(raw_input("enter the number of elments in your list"))

list=[]

for i in range(0,n):
	x=int(raw_input(""))
	list.append(x)

var=int(raw_input("enter the value you want to insert at second position "))

list.insert(1,var)

print(list)
