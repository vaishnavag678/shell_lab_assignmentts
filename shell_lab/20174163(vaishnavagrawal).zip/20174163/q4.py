class val():
    def __init__(self):
        self.s= ""

    def get_String(self):
        self.s = raw_input()

    def print_String(self):
        print(self.s.upper())

s = val()
s.get_String()
s.print_String()
