mkdir -p ./a/b/c/d/e/f
dir=`pwd`
#echo $dir
copy(){
	cp $dir/dummy.txt "$1"/test.txt
	for i in "$1"/*
	do
		if [ -d "$i" ]
		then
			copy "$i"
		fi
	done
}
copy "$dir/a"


