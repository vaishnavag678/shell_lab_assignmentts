directory_path=$1
filename=$2
n=`ls -l $1| grep $filename | wc -l`
if [ $n -ge 1 ]
then 
	ls -l "$1/$2"
else
	echo "File not Found"
fi 
