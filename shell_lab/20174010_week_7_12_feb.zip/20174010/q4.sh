while read -p "Keep entering directory -1 to stop : " dir
do
	if [ $dir = "-1" ]
	then
		break
	fi
	echo $dir>>_temp.txt
done
read -p "Enter the filename : " file
cat _temp.txt | while read d
do 
	n=`ls  $d | grep $file | wc -l`
	if [ $n -ge 1 ]
		then
			echo "Found in $d"
			echo 
			cat $d/$file
	fi
done
rm _temp.txt		
	 
