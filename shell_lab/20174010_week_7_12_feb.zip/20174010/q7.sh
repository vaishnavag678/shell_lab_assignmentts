n=`ps -A | wc -l`
echo "Total Number of processes running on this PC:: $n"
