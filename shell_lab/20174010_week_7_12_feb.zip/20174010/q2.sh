directory_path=$1
echo "The number of files : "
n=`ls -l $directory_path| grep '^-' |wc -l`
echo $n 

