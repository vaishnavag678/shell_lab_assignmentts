cat inp.csv | while read p
				do
					echo $p
					ping -c 4 $p
				done
									
