cat inp.csv | while read ad
do
 	ping -c 5 $ad|cat >>ip.txt
done
