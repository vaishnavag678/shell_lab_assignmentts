#!/bin/bash

echo "give me the two numbers x and y"
read x
read y
echo $x $y
z=0

echo $((x+y))
echo $((x*y))
echo $((x-y))
echo $((x/y))
