#!/bin/bash
who 
