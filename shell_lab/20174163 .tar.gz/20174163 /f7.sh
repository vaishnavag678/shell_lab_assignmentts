#!/bin/bash
read x

if [ $((x%2)) == 0 ]
then
    echo "a is even"
else 
    echo "a is odd"
fi
