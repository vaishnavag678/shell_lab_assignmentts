for i in {1..5}
do
mkdir vessi$i
done

