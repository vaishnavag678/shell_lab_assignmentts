#!/bin/bash

read x

if [ ! -f "$x" ]
then
    echo "file not found "
else
    echo "file found "
fi
