#!/bin/bash
wc -l http.txt

