echo "enter string"
read n1
read n2
n3=$n1$n2
echo "$n3"
