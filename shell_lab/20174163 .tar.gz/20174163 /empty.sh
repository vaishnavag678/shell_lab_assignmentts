#!/bin/bash
cat http.txt
cat vessi.txt
cat http.txt vessi.txt > uv.txt

