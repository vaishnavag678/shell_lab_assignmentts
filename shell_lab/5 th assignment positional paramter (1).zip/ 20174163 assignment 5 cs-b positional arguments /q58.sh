declare -a array=($*)
echo ${array[@]:7}
