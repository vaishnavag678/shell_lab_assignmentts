#!/bin/sh
ls -l
j=$?
cat /home/user/a.txt
i=$?
echo $i $j
