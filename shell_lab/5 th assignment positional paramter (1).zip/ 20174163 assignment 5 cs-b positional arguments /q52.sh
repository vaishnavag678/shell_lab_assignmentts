#!/bin/sh
i=0
count=$#
for x in "$@"
do
i=`expr $i + ${x}`
done
j=`expr $i/$count`
echo $j

