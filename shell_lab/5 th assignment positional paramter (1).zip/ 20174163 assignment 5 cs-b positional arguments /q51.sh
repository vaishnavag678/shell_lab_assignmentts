#!/bin/sh
i=`expr $1 + $2 + $3`

echo $i
echo $#
