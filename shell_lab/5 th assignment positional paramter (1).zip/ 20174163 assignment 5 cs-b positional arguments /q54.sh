#!/bin/sh
who | grep user
j=$?
echo $j
