#!/bin/sh
j=$1 
k=$2
$j $k
ps
echo $$ ##pid of current program
echo $! ##last background process
echo ${!#} ##last argument
echo $? ##exit status
