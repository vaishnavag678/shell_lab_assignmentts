read string
echo ${string:5}
echo ${string:7:0}
echo ${string:7:-2}
echo ${string: -7:-2}
