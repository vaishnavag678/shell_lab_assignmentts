#!/bin/sh
chmod +x $*
