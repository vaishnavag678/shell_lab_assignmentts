##subset sum problem


def ssum(set,n, sum) : 
	
	 
	if (sum == 0) : 
		return True
	if (n == 0 and sum != 0) : 
		return False

	
	if (set[n - 1] > sum) : 
		return ssum(set, n - 1, sum); 
 
	return ssum(set, n-1, sum) or ssum(set, n-1, sum-set[n-1]) 
	
	 
set = [3, -4, 4, -2, -1, 2] 
sum = 0
n = len(set) 
if (ssum(set, n, sum) == True) : 
	print("Found a subset with given sum") 
else : 
	print("No subset with given sum") 
	
 

