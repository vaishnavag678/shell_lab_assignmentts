n=int(raw_input("enter the number till where you want summation"))

sum=0.0


for i in range(1,n+1):
	sum=sum+1.0/i


print sum
