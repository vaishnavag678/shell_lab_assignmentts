import numpy as np
m = np.matrix([[2,3],[4,5]])
np.linalg.inv(m)
