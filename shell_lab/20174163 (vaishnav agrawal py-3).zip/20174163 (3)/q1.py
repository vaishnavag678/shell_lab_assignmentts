class part():
	def __init__(self,arg):
		self.arg=arg		
	def validate(self):
		a=[]
		f=0
		for i in self.arg:
			if i=='(' or i=='[' or i=='(':
				a.append(i)
			else :
				if len(a)==0:
					f=1
					break
				x=a.pop()
				if ( i==')' and x!='(') or (i==']' and x!='[') or (i=='}' and x!='}'):
					f=1
					break
		if f==0:
			print ("right")
		else :
			print ("wrong")
par=part(raw_input("enter the string "))
par.validate()
